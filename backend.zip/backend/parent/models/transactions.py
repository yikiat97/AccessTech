from ..extensions import db



class transactions(db.Model):
    dish_id = db.Column(db.Integer, db.ForeignKey('dishes.id'))
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoice.id'))
